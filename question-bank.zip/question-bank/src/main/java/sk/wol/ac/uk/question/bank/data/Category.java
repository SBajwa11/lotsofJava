package sk.wol.ac.uk.question.bank.data;

import java.util.ArrayList;
import java.util.List;

public class Category {
	
	private String name;
	private List<Question> questions = new ArrayList<>();

	public Category() {
		super();
	}
	
	public List<Question> getQuestions() {
		return questions;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

 
}
