package sk.wol.ac.uk.question.bank.data;

import java.util.ArrayList;
import java.util.List;


/**
 * 
 * Data model to represent
 * <tt>Question</tt> data model.
 * 
 * @author Sabraaj Khasria
 *
 */
public class Question {
	
	 private String questionNumber;
	 private String question;
	 private String answer;
	 private List<String> answersOptions = new ArrayList<>(3);
 
	 
	 public Question() {
		 super();
	 }


	/**
	 * @return the questionNumber
	 */
	public final String getQuestionNumber() {
		return questionNumber;
	}


	/**
	 * @param questionNumber the questionNumber to set
	 */
	public final void setQuestionNumber(String questionNumber) {
		this.questionNumber = questionNumber;
	}


	/**
	 * @return the question
	 */
	public final String getQuestion() {
		return question;
	}


	/**
	 * @param question the question to set
	 */
	public final void setQuestion(String question) {
		this.question = question;
	}


	/**
	 * @return the answersOptions
	 */
	public final List<String> getAnswersOptions() {
		return answersOptions;
	}


	/**
	 * @param answersOptions the answersOptions to set
	 */
	public final void setAnswersOptions(List<String> answersOptions) {
		this.answersOptions = answersOptions;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}

	
}
