package sk.wol.ac.uk.question.bank.core;


/**
 * 
 * This is for future scaling in case 
 * we want to introduce categories.
 * 
 * @author Sabraaj Khasria
 *
 */
public enum QuestionKey {
 
	CATEGORY_SPORT("sport");
	
	
	private String category;
	
	
	private QuestionKey(final String category) {
		this.category = category;
	}
	
	
	public String getCategory() {
		return this.category;
	}
}
