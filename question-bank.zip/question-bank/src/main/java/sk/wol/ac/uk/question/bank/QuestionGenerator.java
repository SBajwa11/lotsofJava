package sk.wol.ac.uk.question.bank;

import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentMap;

import sk.wol.ac.uk.question.bank.core.QuestionKey;
import sk.wol.ac.uk.question.bank.core.QuestionStore;
import sk.wol.ac.uk.question.bank.data.Question;


/**
 * <p>
 * 	This component will
 *  retrieve list of questions from
 *  local cache based on <tt>Category</tt>
 *  that the data model is based on.
 * </p>
 * 
 * @author Sabraaj Bajwa
 *
 */
public final class QuestionGenerator {

	
	public QuestionGenerator() {
		super();
	}
	
	
	public Question getQuestionByCategory(QuestionKey category) {
		/* --- retrieve question from cache --- */
		final ConcurrentMap<String , List<Question>> QUESTIONS = 
				QuestionStore.getInstance().getQuestions();
		
		final List<Question> questions = QUESTIONS.get(category.getCategory());
		
		final Random random = new Random();
		
		final Question randomQuestion = questions.get(random.nextInt(questions.size()));
		
		return randomQuestion;
		
	}
	
}