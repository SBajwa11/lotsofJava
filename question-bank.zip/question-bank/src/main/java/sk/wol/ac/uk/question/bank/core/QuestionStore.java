package sk.wol.ac.uk.question.bank.core;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;

import sk.wol.ac.uk.question.bank.data.Category;
import sk.wol.ac.uk.question.bank.data.Question;
import sk.wol.ac.uk.question.bank.data.Quiz;

public class QuestionStore {

	
	/* -- Eager instantiation - singleton --*/
	private static final QuestionStore INSTANCE = new QuestionStore();
	
	private static final Logger LOGGER = Logger.getLogger(QuestionStore.class.getName());
	
	/* --- complete cache of questions stored based on category --- */
	private final ConcurrentMap<String , List<Question>> QUESTIONS = new ConcurrentHashMap<>(32);
	
	/* --- complete cache of questions from data store --- */
	private final ConcurrentMap<String , Quiz> QUESTIONS_CACHE = new ConcurrentHashMap<>(32);

	private final URL questionSource = ClassLoader.getSystemResource("questions-bank.json");
	 
	
	/** private constructor */
	private QuestionStore() {
		super();
		this.loadQuestions();
		this.getQuestionCache();
	}
	
	public static QuestionStore getInstance() {
		return INSTANCE;
	}
	
	/**
	 * <p>
	 * private method to retrieve
	 * questions from the datastore
	 * in this case <tt>questions-bank.json</tt>
	 * </p>
	 */
	private void loadQuestions() {
		try {			
			if (QUESTIONS_CACHE.get("question") == null ) {
				final ObjectMapper objectMapper = new ObjectMapper();
				QUESTIONS_CACHE.put("questions", objectMapper.readValue(questionSource, Quiz.class));
			} 
 
		} catch (final IOException ioex) {
			final String errorMessage = "question source not found.";
			LOGGER.log(Level.SEVERE, errorMessage, ioex);
		}
		
		return;
	}
	
	private ConcurrentMap<String , Quiz> getQuestionCache() {
		final Quiz quizRoot = QUESTIONS_CACHE.get("questions");
		
		/* --- fetch all categories --- */
		for ( final Category category : quizRoot.getCategory() ) {
			/* --- place in QUESTION cache by category --- */
			final String categoryKey = category.getName();
			if ( QUESTIONS.get(categoryKey) == null ) {
				QUESTIONS.put(categoryKey, category.getQuestions());				
			} 
			
		}
		
		
		return this.QUESTIONS_CACHE;
	}
	
	public ConcurrentMap<String , List<Question>> getQuestions() {
		return this.QUESTIONS;
	}
 
}