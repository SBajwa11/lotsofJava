package sk.wol.ac.uk.question.bank;

import java.util.Scanner;

import sk.wol.ac.uk.question.bank.core.QuestionKey;
import sk.wol.ac.uk.question.bank.data.Question;


/**
 * 
 * <p>
 * main thread to execute <tt>Quiz</tt>
 * program.
 * </p>
 * 
 * @author Sabraaj Bajwa
 *
 */
public class QuizStart {

	public static void main(String... args) {
		System.out.println("Total score out of 30 is " +process());
		System.out.println("*******************");

	}

	private static int process() {
		int scoreCounter = 0;
		int questionCounter = 1;
		boolean loopExit = true;
		final QuestionGenerator questionGenerator = new QuestionGenerator();
		 
		System.out.println("Your questions start now ... Ready?. Continue [y/n]? \n");
 
		while (loopExit) {
			Scanner scan = new Scanner(System.in);
			String input = scan.nextLine();

			switch (input) {
			case "y":
				while ( questionCounter <= 30 ) {
					questionCounter++;
					final Question question = questionGenerator.getQuestionByCategory(QuestionKey.CATEGORY_SPORT);
					System.out.println(question.getQuestion());
					final String answers = getAnswers(question);
					System.out.println("Your options are [please select correct number then HIT ENTER ]: " + answers);
					final String answer = scan.nextLine();	
					
					if ( answer != null && !answer.trim().equals("")) {
						if ( answer.equals(question.getAnswer()) ) {
							System.out.println("correct.\n");
							scoreCounter++;
						} else {
							System.out.println("wrong.\n");
						}
						
					}
				
				}
				loopExit = false;
				break;
			
			case "n":
				System.exit(0);
				break;
			}
			
		}
		
		return scoreCounter;

	}
	

	private static String getAnswers(final Question question) {
		final StringBuilder builder = new StringBuilder(64);

		for (String answer : question.getAnswersOptions()) {
			builder.append(answer + ",");
		}

		return builder.toString();
	}

}
