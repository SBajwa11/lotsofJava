package sk.wol.ac.uk.question.bank.data;

import java.util.ArrayList;
import java.util.List;

public class Quiz {

	private List<Category> category = new ArrayList<>();
 	
	public Quiz() {
		super();
	}

	public List<Category> getCategory() {
		return category;
	}
 
}
